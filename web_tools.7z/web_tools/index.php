<html>
<title>Hacked By SecurityBus</title><style type="text/css">
<!--
.style1 {font-size: 36.0pt}
.style2 {font-size: 14.0pt}
-->
</style><LINK 
href="http://img80.imageshack.us/img80/3262/icorp.jpg" rel="shortcut icon">
</head>
<body bgcolor=black lang=TR link=blue vlink=purple>
<div class=Section1>
<p class=MsoNormal align=center style='text-align:center'><b><font size=7
color=white face="Bodoni MT Poster Compressed"><span style='font-size:36.0pt;
font-family:"Bodoni MT Poster Compressed";color:white;font-weight:bold'>Hacked By </span></font></b>
<b><font size=7 color=red
face="Bodoni MT Poster Compressed"><span style='font-size:36.0pt;font-family:
"Bodoni MT Poster Compressed";color:red;font-weight:bold'>SecurityBus</span></font></b></p>
<center><img src="https://imagizer.imageshack.com/img923/6603/XAT35N.jpg"  alt=  width="225" width="333" height="315">
</center>
<p class=MsoNormal align=center style='text-align:center'><b><font size=7
color=white face="Bodoni MT Poster Compressed"><span style='font-size:36.0pt;
font-family:"Bodoni MT Poster Compressed";color:white;font-weight:bold'>Sorry Admin Your Site Has Been </span></font></b>
<b><font size=7 color=red
face="Bodoni MT Poster Compressed"><span style='font-size:36.0pt;font-family:
"Bodoni MT Poster Compressed";color:red;font-weight:bold'>Hacked</span></font></b></p>
<p class=MsoNormal align=center style='text-align:center'><b><font size=4
color=white face="Bodoni MT Poster Compressed"><span style='font-size:14.0pt;font-family:"Bodoni MT Poster Compressed";
color:white;font-weight:bold'></span></font><font
size=4 color=red face="Bodoni MT Poster Compressed"><span style='font-size:14.0pt;font-family:
"Bodoni MT Poster Compressed";color:red;font-weight:bold'></span></font></b></p>
</div>
</body>
</html>
